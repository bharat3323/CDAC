package com.sms.exception;

@SuppressWarnings("serial")
public class SmsException extends Exception{
	
	public SmsException(String errmsg) {
		super(errmsg);
	}

}
